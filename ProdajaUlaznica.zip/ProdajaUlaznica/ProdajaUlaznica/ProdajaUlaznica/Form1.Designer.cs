﻿namespace ProdajaUlaznica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUlaznica = new System.Windows.Forms.Button();
            this.btnČlanstvo = new System.Windows.Forms.Button();
            this.btnPregledČlanstva = new System.Windows.Forms.Button();
            this.btnPregledUlaznica = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnUlaznica
            // 
            this.btnUlaznica.Location = new System.Drawing.Point(377, 32);
            this.btnUlaznica.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnUlaznica.Name = "btnUlaznica";
            this.btnUlaznica.Size = new System.Drawing.Size(267, 80);
            this.btnUlaznica.TabIndex = 0;
            this.btnUlaznica.Text = "Kupnja ulaznice";
            this.btnUlaznica.UseVisualStyleBackColor = true;
            this.btnUlaznica.Click += new System.EventHandler(this.btnUlaznica_Click);
            // 
            // btnČlanstvo
            // 
            this.btnČlanstvo.Location = new System.Drawing.Point(377, 273);
            this.btnČlanstvo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnČlanstvo.Name = "btnČlanstvo";
            this.btnČlanstvo.Size = new System.Drawing.Size(267, 80);
            this.btnČlanstvo.TabIndex = 1;
            this.btnČlanstvo.Text = "Članstvo kluba";
            this.btnČlanstvo.UseVisualStyleBackColor = true;
            this.btnČlanstvo.Click += new System.EventHandler(this.btnČlanstvo_Click);
            // 
            // btnPregledČlanstva
            // 
            this.btnPregledČlanstva.Location = new System.Drawing.Point(377, 407);
            this.btnPregledČlanstva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPregledČlanstva.Name = "btnPregledČlanstva";
            this.btnPregledČlanstva.Size = new System.Drawing.Size(267, 74);
            this.btnPregledČlanstva.TabIndex = 2;
            this.btnPregledČlanstva.Text = "Pregled članova kluba";
            this.btnPregledČlanstva.UseVisualStyleBackColor = true;
            this.btnPregledČlanstva.Click += new System.EventHandler(this.btnPregledČlanstva_Click);
            // 
            // btnPregledUlaznica
            // 
            this.btnPregledUlaznica.Location = new System.Drawing.Point(377, 149);
            this.btnPregledUlaznica.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnPregledUlaznica.Name = "btnPregledUlaznica";
            this.btnPregledUlaznica.Size = new System.Drawing.Size(267, 80);
            this.btnPregledUlaznica.TabIndex = 3;
            this.btnPregledUlaznica.Text = "Pregled kupljenih ulaznica";
            this.btnPregledUlaznica.UseVisualStyleBackColor = true;
            this.btnPregledUlaznica.Click += new System.EventHandler(this.btnPregledUlaznica_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.btnPregledUlaznica);
            this.Controls.Add(this.btnPregledČlanstva);
            this.Controls.Add(this.btnČlanstvo);
            this.Controls.Add(this.btnUlaznica);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnUlaznica;
        private System.Windows.Forms.Button btnČlanstvo;
        private System.Windows.Forms.Button btnPregledČlanstva;
        private System.Windows.Forms.Button btnPregledUlaznica;
    }
}

