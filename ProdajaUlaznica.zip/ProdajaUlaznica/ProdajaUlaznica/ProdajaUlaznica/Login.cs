﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;
using System.IO;

namespace ProdajaUlaznica
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        public string FromXMLusername = "";
        public string FromXMLPassword = "";

        private void Clear()
        {
            txtBxUsername.Clear();
            txtBxPassword.Clear();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string user = txtBxUsername.Text;
            string lozinka = txtBxPassword.Text;

            XDocument doc = XDocument.Load(Application.StartupPath.ToString() + @"\users.xml");
            var odabraniKorisnik = from x in doc.Descendants("user").Where(x => (string)x.Element("username") == txtBxUsername.Text)
                                   select new
                                   {
                                       XMLuser = x.Element("username").Value,
                                       XMLpwd = x.Element("pwd").Value,
                                   };

            foreach (var x in odabraniKorisnik)
            {
                FromXMLusername = x.XMLuser;
                FromXMLPassword = x.XMLpwd;
            }



            if (user == FromXMLusername)
            {
                if (lozinka == FromXMLPassword)
                {

                    MessageBox.Show("Uspjesno ulogirani");
                    Form1 pocetna = new Form1();
                    pocetna.Show();



                }
                else
                {
                    MessageBox.Show("Netocno upisana lozinka");
                    Clear();
                }
            }
            else
            {
                MessageBox.Show("Netocno upisani username");
                Clear();
            }
        }
    }
}
