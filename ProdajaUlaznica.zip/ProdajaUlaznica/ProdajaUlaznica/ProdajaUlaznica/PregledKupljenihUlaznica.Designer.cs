﻿namespace ProdajaUlaznica
{
    partial class PregledKupljenihUlaznica
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richTxtBxUlaznice = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtBxOibUlaznicePretraga = new System.Windows.Forms.TextBox();
            this.btnPretraziUlaznice = new System.Windows.Forms.Button();
            this.dateTimeUlaznicaPretraga = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // richTxtBxUlaznice
            // 
            this.richTxtBxUlaznice.Location = new System.Drawing.Point(261, 12);
            this.richTxtBxUlaznice.Name = "richTxtBxUlaznice";
            this.richTxtBxUlaznice.Size = new System.Drawing.Size(455, 341);
            this.richTxtBxUlaznice.TabIndex = 0;
            this.richTxtBxUlaznice.Text = "";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(283, 396);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "OIB";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(283, 460);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Datum rođenja";
            // 
            // TxtBxOibUlaznicePretraga
            // 
            this.TxtBxOibUlaznicePretraga.Location = new System.Drawing.Point(404, 396);
            this.TxtBxOibUlaznicePretraga.Name = "TxtBxOibUlaznicePretraga";
            this.TxtBxOibUlaznicePretraga.Size = new System.Drawing.Size(145, 22);
            this.TxtBxOibUlaznicePretraga.TabIndex = 3;
            // 
            // btnPretraziUlaznice
            // 
            this.btnPretraziUlaznice.Location = new System.Drawing.Point(668, 389);
            this.btnPretraziUlaznice.Name = "btnPretraziUlaznice";
            this.btnPretraziUlaznice.Size = new System.Drawing.Size(177, 88);
            this.btnPretraziUlaznice.TabIndex = 5;
            this.btnPretraziUlaznice.Text = "Pretraži";
            this.btnPretraziUlaznice.UseVisualStyleBackColor = true;
            // 
            // dateTimeUlaznicaPretraga
            // 
            this.dateTimeUlaznicaPretraga.Location = new System.Drawing.Point(404, 460);
            this.dateTimeUlaznicaPretraga.Name = "dateTimeUlaznicaPretraga";
            this.dateTimeUlaznicaPretraga.Size = new System.Drawing.Size(200, 22);
            this.dateTimeUlaznicaPretraga.TabIndex = 6;
            // 
            // PregledKupljenihUlaznica
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1021, 580);
            this.Controls.Add(this.dateTimeUlaznicaPretraga);
            this.Controls.Add(this.btnPretraziUlaznice);
            this.Controls.Add(this.TxtBxOibUlaznicePretraga);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.richTxtBxUlaznice);
            this.Name = "PregledKupljenihUlaznica";
            this.Text = "PregledKupljenihUlaznica";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox richTxtBxUlaznice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtBxOibUlaznicePretraga;
        private System.Windows.Forms.Button btnPretraziUlaznice;
        private System.Windows.Forms.DateTimePicker dateTimeUlaznicaPretraga;
    }
}